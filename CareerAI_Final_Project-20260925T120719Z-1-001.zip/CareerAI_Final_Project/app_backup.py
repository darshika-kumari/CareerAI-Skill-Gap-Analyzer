
import streamlit as st
import os
import re
import torch
import faiss

from pypdf import PdfReader
from sentence_transformers import SentenceTransformer, util
from transformers import AutoTokenizer, AutoModelForCausalLM


# ============================================================
# CAREERAI
# AI Career Guidance, Skill-Gap Analysis & Roadmap System
# ============================================================

st.set_page_config(
    page_title="CareerAI",
    page_icon="🎯",
    layout="wide"
)

st.title("🎯 CareerAI")
st.subheader("AI Career Guidance, Skill-Gap Analysis & Personalized Roadmap")


# ============================================================
# LOAD PROJECT
# ============================================================

PROJECT_PATH = "/content/drive/MyDrive/CareerAI_Final_Project"
KNOWLEDGE_PATH = os.path.join(PROJECT_PATH, "knowledge_base")
INDEX_PATH = os.path.join(KNOWLEDGE_PATH, "career_index.faiss")


# ============================================================
# LOAD KNOWLEDGE BASE
# ============================================================

@st.cache_resource
def load_knowledge():

    documents = []
    names = []

    for filename in os.listdir(KNOWLEDGE_PATH):

        if filename.endswith(".txt"):

            path = os.path.join(
                KNOWLEDGE_PATH,
                filename
            )

            with open(path, "r", encoding="utf-8") as f:
                documents.append(f.read())

            names.append(filename)

    return documents, names


documents_text, document_names = load_knowledge()


# ============================================================
# LOAD EMBEDDING MODEL + FAISS
# ============================================================

@st.cache_resource
def load_embedding_system():

    model = SentenceTransformer(
        "all-MiniLM-L6-v2"
    )

    index = faiss.read_index(
        INDEX_PATH
    )

    return model, index


embedding_model, index = load_embedding_system()


# ============================================================
# LOAD LLM
# ============================================================

@st.cache_resource
def load_llm():

    model_name = "Qwen/Qwen2.5-1.5B-Instruct"

    tokenizer = AutoTokenizer.from_pretrained(
        model_name
    )

    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        torch_dtype=torch.float16,
        device_map="auto"
    )

    return tokenizer, model


# ============================================================
# PDF READER
# ============================================================

def extract_text_from_pdf(uploaded_file):

    reader = PdfReader(uploaded_file)

    text = ""

    for page in reader.pages:

        page_text = page.extract_text()

        if page_text:
            text += page_text + "\n"

    return text.strip()


# ============================================================
# PROFILE EXTRACTION
# ============================================================

def extract_candidate_profile(resume_text):

    text = resume_text.lower()

    skill_categories = {

        "Programming & Technology": [
            "python", "java", "c++", "c",
            "javascript", "html", "css",
            "sql", "git", "docker", "api"
        ],

        "AI & Machine Learning": [
            "machine learning", "deep learning",
            "neural networks",
            "natural language processing",
            "nlp", "bert", "transformers",
            "tensorflow", "pytorch",
            "computer vision"
        ],

        "Data": [
            "data science", "data analysis",
            "pandas", "numpy", "statistics",
            "data visualization",
            "excel", "power bi", "tableau"
        ],

        "Business & Commerce": [
            "accounting", "finance",
            "financial analysis",
            "business analysis",
            "marketing", "sales", "economics"
        ],

        "Legal": [
            "legal research", "contract",
            "contracts", "litigation",
            "compliance", "legal writing",
            "case analysis"
        ],

        "Communication & Professional": [
            "communication", "leadership",
            "teamwork", "problem solving",
            "research", "writing",
            "presentation",
            "project management"
        ]
    }

    profile = {
        "education": [],
        "skills": {},
        "projects": [],
        "career_interests": []
    }

    for category, skills in skill_categories.items():

        found = []

        for skill in skills:

            if skill in text:
                found.append(skill)

        if found:
            profile["skills"][category] = found

    project_section = re.search(
        r"projects?(.*?)(career interest|current level|$)",
        text,
        re.IGNORECASE | re.DOTALL
    )

    if project_section:

        for line in project_section.group(1).split("\n"):

            line = line.strip()

            if line:
                profile["projects"].append(line)

    interest_section = re.search(
        r"career interest[s]?(.*?)(current level|$)",
        text,
        re.IGNORECASE | re.DOTALL
    )

    if interest_section:

        for line in interest_section.group(1).split("\n"):

            line = line.strip()

            if line:
                profile["career_interests"].append(line)

    return profile


# ============================================================
# CAREER SKILLS
# ============================================================

career_skill_requirements = {

    "AI/ML Engineer": [
        "python", "machine learning",
        "deep learning", "neural networks",
        "nlp", "transformers", "statistics",
        "data processing", "model evaluation",
        "api", "deployment", "git", "docker"
    ],

    "Data Scientist": [
        "python", "sql", "statistics",
        "probability", "data analysis",
        "machine learning", "pandas",
        "numpy", "data visualization"
    ],

    "Data Analyst": [
        "sql", "excel", "python",
        "data cleaning", "statistics",
        "power bi", "tableau",
        "data visualization",
        "business analysis"
    ],

    "Software Engineer": [
        "c++", "java", "python",
        "data structures", "algorithms",
        "object-oriented programming",
        "sql", "git",
        "software development"
    ]
}


# ============================================================
# RAG SEARCH
# ============================================================

def search_knowledge(query, top_k=2):

    query_embedding = embedding_model.encode(
        [query],
        convert_to_numpy=True
    ).astype("float32")

    distances, indices = index.search(
        query_embedding,
        top_k
    )

    results = []

    for distance, idx in zip(
        distances[0],
        indices[0]
    ):

        results.append(
            documents_text[idx]
        )

    return results


# ============================================================
# GENERATE AI RESPONSE
# ============================================================

def generate_response(
    profile_text,
    career,
    matched,
    missing,
    context
):

    tokenizer, model = load_llm()

    prompt = f"""
You are CareerAI, an AI career guidance assistant.

CANDIDATE PROFILE:
{profile_text}

TARGET CAREER:
{career}

MATCHED SKILLS:
{matched}

SKILLS TO DEVELOP:
{missing}

CAREER KNOWLEDGE:
{context}

Create practical career guidance with these sections:

1. Candidate Summary
2. Existing Strengths
3. Skill Gaps
4. Why This Career Could Match
5. 3-Stage Learning Roadmap
6. Recommended Projects
7. Recommended Next Steps

Rules:
- Do not invent information.
- Do not assume a degree determines a career.
- Be transparent about missing information.
- Give practical beginner-friendly guidance.
"""

    messages = [
        {
            "role": "system",
            "content":
            "You are CareerAI, a helpful career guidance assistant."
        },
        {
            "role": "user",
            "content": prompt
        }
    ]

    formatted = tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True
    )

    inputs = tokenizer(
        formatted,
        return_tensors="pt"
    ).to(model.device)

    with torch.no_grad():

        outputs = model.generate(
            **inputs,
            max_new_tokens=700,
            temperature=0.7,
            do_sample=True,
            top_p=0.9
        )

    generated = outputs[0][
        inputs["input_ids"].shape[1]:
    ]

    return tokenizer.decode(
        generated,
        skip_special_tokens=True
    ).strip()


# ============================================================
# USER INTERFACE
# ============================================================

st.markdown(
    "Upload your resume and optionally enter your target career."
)

uploaded_file = st.file_uploader(
    "📄 Upload Resume (PDF)",
    type=["pdf"]
)

career_options = list(
    career_skill_requirements.keys()
)

target_career = st.selectbox(
    "🎯 Select Target Career",
    ["Choose a career"] + career_options
)


if uploaded_file and target_career != "Choose a career":

    if st.button("🚀 Analyze My Career"):

        with st.spinner(
            "CareerAI is analyzing your profile..."
        ):

            resume_text = extract_text_from_pdf(
                uploaded_file
            )

            profile = extract_candidate_profile(
                resume_text
            )

            candidate_skills = set()

            for skills in profile["skills"].values():

                for skill in skills:
                    candidate_skills.add(
                        skill.lower()
                    )

            requirements = career_skill_requirements[
                target_career
            ]

            matched = [
                skill
                for skill in requirements
                if skill in candidate_skills
            ]

            missing = [
                skill
                for skill in requirements
                if skill not in candidate_skills
            ]

            query = f"""
            Skills required for {target_career},
            projects, tools and learning roadmap.
            """

            retrieved = search_knowledge(
                query,
                top_k=2
            )

            context = "\n\n".join(
                retrieved
            )

            profile_text = str(profile)

            response = generate_response(
                profile_text,
                target_career,
                matched,
                missing,
                context
            )

        st.success("Career analysis completed!")

        col1, col2 = st.columns(2)

        with col1:

            st.subheader("💪 Existing Strengths")

            if matched:

                for skill in matched:
                    st.write("✅", skill)

            else:
                st.write(
                    "No matching skills detected."
                )

        with col2:

            st.subheader("📚 Skills to Develop")

            if missing:

                for skill in missing:
                    st.write("🔹", skill)

            else:
                st.write(
                    "No major gaps detected."
                )

        st.divider()

        st.subheader("🤖 CareerAI Guidance")

        st.write(response)

else:

    st.info(
        "Upload a PDF resume and select a target career to begin."
    )
